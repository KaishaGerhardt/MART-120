onEvent("GetStartedButton", "click", function(){
playSound("assets/category_achievements/lighthearted_bonus_objective_1.mp3");
setScreen("screen1");
});
onEvent("Smash", "click", function(){
playSound("assets/category_male_voiceover/congratulations_male.mp3");
setScreen("Smashwithoak");
});
onEvent("Pass", "click", function(){
playSound("assets/category_human/character_kimberly_canceled_2.mp3");
setScreen("pass1");
});
onEvent("pass2", "click", function(){
playSound("assets/category_human/character_calvin_no_1.mp3");
setScreen("pass2");
});
onEvent("PinkTreeyess", "click", function(){
playSound("assets/category_human/character_kimberly_are_you_ready_1.mp3");
setScreen("Passwithpinktree");
});
onEvent("pass2", "click", function(){
playSound("assets/category_human/character_jimmy_awesome_1.mp3");
setScreen("Passwithpinktree");
});
onEvent("pinktreepass", "click", function(){
playSound("assets/category_human/character_yury_can_i_help_you_1.mp3");
setScreen("pass2");
});
onEvent("pass2", "click", function(){
playSound("assets/category_human/character_yury_i_miss_you_2.mp3");
setScreen("screen5");
});
onEvent("passred", "click", function(){
playSound("assets/category_human/character_sharon_ok_2.mp3");
setScreen("datewithredtree");
});
